package com.desa.demo.exception;

public class CuentaException extends RuntimeException {
    public CuentaException(String message) {
        super(message);
    }
}
