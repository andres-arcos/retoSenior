package com.desa.demo.exception;

public class ClienteException extends RuntimeException {
    public ClienteException(String message) {
        super(message);
    }
}
