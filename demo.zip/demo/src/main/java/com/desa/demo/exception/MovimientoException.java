package com.desa.demo.exception;

public class MovimientoException extends RuntimeException {
    public MovimientoException(String message) {
        super(message);
    }
}
